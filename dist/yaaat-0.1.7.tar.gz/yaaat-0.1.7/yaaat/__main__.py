"""Entry point when running python -m yaaat"""
from yaaat.main import main

if __name__ == "__main__":
    main()